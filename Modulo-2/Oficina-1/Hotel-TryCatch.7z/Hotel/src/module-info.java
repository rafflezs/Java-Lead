module hotel {
	requires java.desktop;
}