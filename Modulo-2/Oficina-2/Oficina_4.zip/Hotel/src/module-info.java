module Hotel {
	requires java.desktop;
}